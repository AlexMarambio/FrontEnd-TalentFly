import React from 'react'
import Register from '../../components/Register/Register1'
import Register2 from '../../components/Register/Register2'

interface Props {}

const RegPage = (props: Props) => {
  return (
    <div>
        <Register2 />
    </div>
  )
}

export default RegPage