import React from 'react'
import Login from '../../components/Login/Login'

interface Props {}

const LoginPage = (props: Props) => {
  return (
    <div>
        <Login />
    </div>
  )
}

export default LoginPage