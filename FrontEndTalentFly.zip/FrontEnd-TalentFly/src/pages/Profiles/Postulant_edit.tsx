import React from 'react'
import Postulants_edit from '../../components/Profile/ProfilePostulant_edit'

interface Props {}

const Postulant_edit = (props: Props) => {
  return (
    <div>
        <Postulants_edit />
    </div>
  )
}

export default Postulant_edit