import React from 'react'
import Postulants from '../../components/Profile/ProfilePostulant'

interface Props {}

const Postulant = (props: Props) => {
  return (
    <div>
        <Postulants />
    </div>
  )
}

export default Postulant